from flask import Flask, request, jsonify, redirect
import string, random, logging
from datetime import datetime, timedelta

app = Flask(__name__)

# ---------------------------
# Logging Middleware
# ---------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

@app.before_request
def log_request_info():
    logging.info(f"Incoming Request: {request.method} {request.url}")
    logging.info(f"Headers: {dict(request.headers)}")
    logging.info(f"Body: {request.get_data()}")

# ---------------------------
# In-Memory Database
# ---------------------------
urls = {}  
# {shortcode: {"url": str, "expiry": datetime, "created_at": datetime, "clicks": int, "clickData": []}}

# ---------------------------
# Helper Functions
# ---------------------------
def generate_shortcode(length=6):
    """Generate a random shortcode"""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def is_valid_url(url):
    return url.startswith("http://") or url.startswith("https://")

# ---------------------------
# Root Route (Test in Browser)
# ---------------------------
@app.route("/", methods=["GET"])
def home():
    return "✅ Flask URL Shortener Microservice is Running!"

# ---------------------------
# API Endpoints
# ---------------------------

# 1. Create Short URL
@app.route("/shorturls", methods=["POST"])
def create_short_url():
    data = request.get_json()

    if not data or "url" not in data:
        return jsonify({"error": "URL is required"}), 400

    original_url = data["url"]
    if not is_valid_url(original_url):
        return jsonify({"error": "Invalid URL format"}), 400

    validity_minutes = data.get("validity", 30)
    expiry = datetime.utcnow() + timedelta(minutes=validity_minutes)

    shortcode = data.get("shortcode")
    if not shortcode:
        shortcode = generate_shortcode()
    if shortcode in urls:
        return jsonify({"error": "Shortcode already exists"}), 400

    urls[shortcode] = {
        "url": original_url,
        "expiry": expiry,
        "created_at": datetime.utcnow(),
        "clicks": 0,
        "clickData": []
    }

    response = {
        "shortLink": f"http://localhost:5000/{shortcode}",
        "expiry": expiry.isoformat() + "Z"
    }
    return jsonify(response), 201


# 2. Redirect to Original URL
@app.route("/<shortcode>", methods=["GET"])
def redirect_url(shortcode):
    if shortcode not in urls:
        return jsonify({"error": "Shortcode not found"}), 404

    entry = urls[shortcode]
    if datetime.utcnow() > entry["expiry"]:
        return jsonify({"error": "Short link has expired"}), 410  # 410 Gone

    # Update statistics
    entry["clicks"] += 1
    entry["clickData"].append({
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "referrer": request.referrer or "Direct",
        "location": "Unknown"
    })

    return redirect(entry["url"], code=302)


# 3. Retrieve Short URL Statistics
@app.route("/shorturls/<shortcode>", methods=["GET"])
def get_statistics(shortcode):
    if shortcode not in urls:
        return jsonify({"error": "Shortcode not found"}), 404

    entry = urls[shortcode]
    stats = {
        "clicks": entry["clicks"],
        "originalUrl": entry["url"],
        "createdAt": entry["created_at"].isoformat() + "Z",
        "expiry": entry["expiry"].isoformat() + "Z",
        "clickData": entry["clickData"]
    }
    return jsonify(stats), 200


# ---------------------------
# Run the App
# ---------------------------
if __name__ == "__main__":
    app.run(debug=True)
